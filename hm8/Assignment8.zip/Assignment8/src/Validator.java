import java.util.Optional;

public class Validator implements Runnable {

	@Override
	public void run() {
		

	}
	
    static Optional<String> validate(Tx t) {
        if (t.id == null || t.id.isEmpty()) return Optional.of("missing_id");
        if (t.account == null || t.account.isEmpty()) return Optional.of("missing_account");
        if (t.epochSec < 946684800L || t.epochSec >= 4102444800L) return Optional.of("bad_time"); // 2000..2100
        if (Math.abs(t.cents) > 10_000_00L) return Optional.of("amount_out_of_range");
        return Optional.empty();
    }

}
