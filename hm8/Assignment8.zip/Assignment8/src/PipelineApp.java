import java.io.*;
import java.nio.file.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.stream.*;

/**
 * Graduate-level Java pipeline:
 *   Reader (CSV) -> Validator(workers) -> Aggregator(single)
 * Backpressure via bounded queues, graceful shutdown, error routing, de-dup for exactly-once aggregation.
 *
 * Usage:
 *   java PipelineApp <csvPath> [q1Cap=256] [q2Cap=256] [validators=2] [errorOut=errors.csv]
 */

public class PipelineApp {

    

    // ====== Main driver ======
    public static void main(String[] args) throws Exception {
        
    	

        Path csvPath = Paths.get(args[0]);
        
        /* you will have to figure out what
         * arguments go in the constructors
         * 
         * You will have to create queues that are
         * shared by the relevant threads
         */
        
        Reader reader = new Reader();
        Validator validator1 = new Validator();
        Validator validator2 = new Validator();
        ErrorWriter errorWriter = new ErrorWriter();
        Aggregator agg = new Aggregator();
        
        /* once the threads are done, you should
         * be able to get all of the data from the
         * aggregator
         */
        
        Map<AggKey, Long> totals = agg.snapshotTotals();


        
        // We need a reference to the Aggregator to snapshot totals.
        // Since aggregator was created above, capture it via a final variable:
        // (Refactor to keep a reference)
    }
}
//====== Data model ======
final class Tx {
    final String id;
    final String account;
    final long epochSec;
    final long cents;
    Tx(String id, String account, long epochSec, long cents) {
        this.id = id; this.account = account; this.epochSec = epochSec; this.cents = cents;
    }
    public String toString() { return id + "," + account + "," + epochSec + "," + cents; }
}

final class AggKey {
    final String account;
    final LocalDate day; // UTC day
    AggKey(String account, LocalDate day) { this.account = account; this.day = day; }
    @Override public boolean equals(Object o) {
        if (!(o instanceof AggKey)) return false;
        AggKey k = (AggKey)o;
        return Objects.equals(account, k.account) && Objects.equals(day, k.day);
    }
    @Override public int hashCode() { return Objects.hash(account, day); }
    @Override public String toString() { return account + " @ " + day; }
}

// ====== Messaging between stages ======
interface Msg {}
final class MsgTx implements Msg {
    final Tx tx;
    final long t0Nanos;
    MsgTx(Tx tx, long t0Nanos) { this.tx = tx; this.t0Nanos = t0Nanos; }
}
final class Stop implements Msg {
    static final Stop INSTANCE = new Stop();
    private Stop() {}
}

