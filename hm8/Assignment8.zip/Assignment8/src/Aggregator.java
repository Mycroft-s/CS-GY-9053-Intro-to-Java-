import java.util.Map;


public class Aggregator implements Runnable {
	private  Map<String, Boolean> seenIds;
    private  Map<AggKey, Long> totals;
	@Override
	public void run() {
		

	}
	
	Map<AggKey, Long> snapshotTotals() {
		return null;
	}

}
