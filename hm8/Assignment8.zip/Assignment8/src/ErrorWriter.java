
public class ErrorWriter implements Runnable {

	@Override
	public void run() {

	}

}
