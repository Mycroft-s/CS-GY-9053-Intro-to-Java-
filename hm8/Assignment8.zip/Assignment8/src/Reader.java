

public class Reader implements Runnable {

	@Override
	public void run() {
		// TODO Auto-generated method stub

	}
	
	static Tx parse(String line) {
        // Simple CSV split; for real CSV use a parser
        String[] p = line.split(",", -1);
        if (p.length < 4) {
            // Put a clearly bad row; validator will route it
            return new Tx("", "", 0L, 0L);
        }
        long epochSecs;
        long cents; 
        try {
        	epochSecs = Long.parseLong(p[2].trim());
        	cents = Long.parseLong(p[3].trim());
        } catch (Exception e) {
        	System.err.print("error parsing line " + line);
        	return new Tx("", "", 0L, 0L);
        }
        return new Tx(p[0].trim(), p[1].trim(),
                Long.parseLong(p[2].trim()),
                Long.parseLong(p[3].trim()));
    }

}
