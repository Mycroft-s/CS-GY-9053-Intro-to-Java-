package triplet;

public class Triplet {

}
