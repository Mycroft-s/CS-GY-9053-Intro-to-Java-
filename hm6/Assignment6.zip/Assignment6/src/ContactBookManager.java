import javax.swing.*;
import javax.swing.table.DefaultTableModel;

public class ContactBookManager extends JFrame {
    private JTable contactTable;
    private DefaultTableModel tableModel;
    
    private static final String DEFAULT_DIR = System.getProperty("user.dir");

    public ContactBookManager() {
        super("Contact Book Manager");
        
        // Table Model and JTable
        String[] columnNames = {"Name", "Street", "City", "State", "Phone", "Email"};
        tableModel = new DefaultTableModel(columnNames, 0);
        contactTable = new JTable(tableModel);
        
    }
    
    private void showADialog() {
    	JOptionPane.showMessageDialog(this, "This is a dialog you can use for messages!");
    }
    
    
    // Saves contacts to a CSV file
    private void saveContacts() {
    	JFileChooser chooser = new JFileChooser(DEFAULT_DIR);
    	int returnVal = chooser.showSaveDialog(this);
    	if(returnVal == JFileChooser.APPROVE_OPTION) {
    		String fileName = chooser.getSelectedFile().getName();
	        
    	}
    	return;
    }

    // Loads contacts from a CSV file
    private void loadContacts() {
    	JFileChooser chooser = new JFileChooser(DEFAULT_DIR);
    	int returnVal = chooser.showOpenDialog(this);
    	if(returnVal == JFileChooser.APPROVE_OPTION) {
	        String fileName = chooser.getSelectedFile().getName();
	        
    	}
    	return;
    }

    public static void main(String[] args) {
    	JFrame frame = new JFrame("Contact Book Manager");
        frame.setVisible(true);
    }
}
