public class MyInitials {
    public static void main(String[] args) {
        System.out.println("M   M  H   H  DDDD ");
        System.out.println("MM MM  H   H  D   D");
        System.out.println("M M M  H   H  D   D");
        System.out.println("M   M  HHHHH  D   D");
        System.out.println("M   M  H   H  D   D");
        System.out.println("M   M  H   H  D   D");
        System.out.println("M   M  H   H  DDDD ");
    }
}
