
public class PrintResults {

	public static void main(String[] args) {
		
		System.out.println("The value of 1+1 is " + (1+1));
		int a = 10 + 5;
		int b = 50 - 23;
		int c = 12 * 13;
		double d = 20.0 / 3.0;
		int e = 100 % 7;
		double f = Math.pow(4, 3);
		
		 System.out.println("The value of a is " + a);
	     System.out.println("The value of b is " + b);
	     System.out.println("The value of c is " + c);
	     System.out.println("The value of d is " + d);
	     System.out.println("The value of e is " + e);
	     System.out.println("The value of f is " + f);
	}
}
