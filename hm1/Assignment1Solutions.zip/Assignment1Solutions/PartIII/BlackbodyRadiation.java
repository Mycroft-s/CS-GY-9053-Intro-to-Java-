public class BlackbodyRadiation {

	final static double C = 3e8;
	final static double H = 6.626e-34;
	final static double K_B = 1.381e-23;
	public static double calculateEnergy (double nu, double T) {
		/* the typo-laden equation I put in
		 * the problem set would be this:
		 */
		double factor1 = 2*H*Math.pow(nu, 3) / Math.pow(C, 2);
		double exponent = H*nu/(K_B*T);
		double result = factor1*1/(Math.pow(Math.E, exponent-1));
		System.out.println("typo result is " + result);
		/* however, the actual equation is: */
		result = factor1*1/(Math.pow(Math.E, exponent) - 1);

		System.out.println("actual result is " + result);
		
		return result;
	}
	
	public static void main(String[] args) {
		
		double sun_nu = C/500e-9;
		double sun_temp = 5800;
		double betel_nu = C/970e-9;
		double betel_temp = 3500;
		double sun_energy = calculateEnergy(sun_nu, sun_temp);
		double betel_energy = calculateEnergy(betel_nu, betel_temp);
		System.out.println("I for the Sun is " + sun_energy);
		double wrong_sun = calculateEnergy(betel_nu, sun_temp);
		System.out.println("I for the Sun with incorrect wavelength is " + wrong_sun);
		System.out.println("I for the betelgeuse is " + betel_energy);
		

	}
}