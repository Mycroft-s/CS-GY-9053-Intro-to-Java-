
public class MyInitials {

	public static void main(String[] args) {
        // each letter is 5 characters long, and there are two spaces between letters
        // so you're going to use 19 spaces for 3 initials
        // each letter is 7 characters tall, so you will have 7 println statements
        System.out.println("DDDD   K   K    CCC ");
        System.out.println("D   D  K  K    C   C");
        System.out.println("D   D  K K     C");
        System.out.println("D   D  KK      C");
        System.out.println("D   D  K K     C");
        System.out.println("D   D  K  K    C   C");
        System.out.println("DDDD   K   K    CCC");
	}
}
