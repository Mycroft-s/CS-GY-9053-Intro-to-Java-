public class BlackbodyRadiation {

	public static double calculateEnergy () {
		
		return -1;
	}
	
	public static void main(String[] args) {
		
		
		double energy = calculateEnergy();
		System.out.println("I for the Sun is ");
		System.out.println("I for the betelgeuse is ");
		

	}
}