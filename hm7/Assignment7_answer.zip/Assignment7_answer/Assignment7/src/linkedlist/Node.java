package linkedlist;

class Node<T> {
    T val;
    Node<T> next;
    Node(T v) { this.val = v; }
}
