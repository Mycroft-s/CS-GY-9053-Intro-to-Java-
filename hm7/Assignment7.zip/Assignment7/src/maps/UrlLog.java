package maps;
public class UrlLog {

	
	
	public static void main(String[] args) {
	
	}
	

}
