package linkedlist;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.Queue;
import java.util.Random;

public class CustomLinkedList<T> implements Queue<T> {

	
	public CustomLinkedList() {
	
	}
	
	public boolean add(T val) {
		return false;
	}
	
	public T get(int index) throws IndexOutOfBoundsException {
		return null;
	}
	
	public T remove(int index) throws IndexOutOfBoundsException {
		return null;
	}
	
	

	@Override
	public boolean addAll(Collection<? extends T> arg0) {
		// Ignore
		return false;
	}

	@Override
	public void clear() {
		
	}

	@Override
	public boolean contains(Object v) {
		
		return false;
	}

	@Override
	public boolean containsAll(Collection<?> arg0) {
		// Ignore
		return false;
	}

	@Override
	public boolean isEmpty() {
		return false;
	}

	@Override
	public Iterator<T> iterator() {
		// Ignore
		return null;
	}

	@Override
	public boolean removeAll(Collection<?> arg0) {
		// Ignore
		return false;
	}

	@Override
	public boolean retainAll(Collection<?> arg0) {
		// Ignore
		return false;
	}

	@Override
	public int size() {
		return -1;
	}

	@Override
	public Object[] toArray() {
		// Ignore
		return null;
	}

	@Override
	public <T> T[] toArray(T[] arg0) {
		// Ignore
		return null;
	}

	@Override
	public T element() {
		return null;
	}

	@Override
	public boolean offer(T val) {
		return true;
	}

	@Override
	public T peek() {
		return null;
	}

	@Override
	public T poll() {
		return null;
	}

	@Override
	public T remove() {
		return null;
	}

	@Override
	public boolean remove(Object obj) {
		
		return false;
	}
	
	public static void main(String[] args) {
		final int COUNT = 1_000_000;
		
		System.out.println("time for library LL: " );
		
		System.out.println("time for custom LL: ");

	}

	
	
}
