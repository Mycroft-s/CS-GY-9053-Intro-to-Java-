package linkedlist;

public class Node {

	
}
