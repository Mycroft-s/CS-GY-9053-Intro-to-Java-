package sets;
import java.util.*;
import java.io.*;

public class DuplicateWords {

	public static String cleanString(String originalString) {
		String cleanedString = originalString.replaceAll("\\p{Punct}", "");
		cleanedString = cleanedString.replaceAll("[“’”]+", "");
		return cleanedString;
	}
	
	public static void main(String[] args) throws IOException {
		
		System.out.println("number of duplicate words: ");
		System.out.println("number of single words: ");
	}
}
