
public class  Leibniz {

	public static double estimatePi(int iterations) {
		return -1;
	}
	
	public static void main(String[] args) {
		int iterations = 0;
		// result must be to within 10-5!
		// Math.abs(Math.PI - pi) will give you the difference
		// between PI and your estimation.
		double pi=0;
		pi = estimatePi(iterations);
		
	}
}
