
public class MirrorString {

	public static String mirrorString(String input) {
		String result = "";
		return result;
	}
	public static void main(String[] args) {
		String input = "hello";
		System.out.println("mirror string of hello is ");

	}

}
