
public class Acronym {

	public String createAcronym(String input) {
		String result = "";
		return result;
	}
	public static void main(String[] args) {
		String s1 = "as soon as possible";
		String s2 = "The quick brown fox jumps over the lazy dog";

	}

}
