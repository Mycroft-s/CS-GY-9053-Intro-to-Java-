package employees;

public class Employee {

}
