package workplace;

public class Workplace {

}
